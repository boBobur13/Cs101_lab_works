#include <iostream>

using namespace std;

int main()
{
  int a;
    cin>>a;
    if (a>0) {
        cout<< "Positive" << endl;
    } else if (a==0) {
        cout<< "Neither positive nor negative" << endl;
        }
    else {
        cout<< "Negative" << endl;
    }


    return 0;
}
